package day04;
//if...else if结构的演示
public class IfElseIfDemo {
    public static void main(String[] args) {
        /*
          3.if...else if结构: 多条路
            1)语法:
                if(boolean-1){
                  语句块1
                }else if(boolean-2){
                  语句块2
                }else if(boolean-3){
                  语句块3
                }else{
                  语句块4
                }
            2)执行过程:
                判断boolean-1，若为true则执行语句块1(结束)，若为false则
                再判断boolean-2，若为true则执行语句块2(结束)，若为false则
                再判断boolean-3，若为true则执行语句块3(结束)，若为false则执行语句块4(结束)
            3)说明:
                语句块1/2/3/4，必走其中之一-------多选1
         */
    }
}
























