package day04;
//do...while结构的演示
public class DoWhileDemo {
    public static void main(String[] args) {
        /*
          2.do...while结构:
            1)语法:
                do{
                  语句块
                }while(boolean);
            2)执行过程:
                先执行语句块，再判断boolean的值，若为true则
                再执行语句块，再判断boolean的值，若为true则
                再执行语句块，如此反复，直到boolean为false时，do...while结构
         */
    }
}














