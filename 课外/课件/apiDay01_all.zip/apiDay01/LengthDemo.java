package apiday01;

/**
 * int length():
 * 获取字符串的长度(字符个数)
 */
public class LengthDemo {
    public static void main(String[] args) {
        String str = "我爱Java!";
        int len = str.length(); //获取str的长度
        System.out.println(len); //7
    }
}


















