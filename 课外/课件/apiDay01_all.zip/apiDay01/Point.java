package apiday01;
//点
public class Point { //很多框架都是基于getter/setter来取值、赋值的----一种习惯
    private int x;
    private int y;

    public int getX(){ //getter获取值
        return this.x;
    }
    public void setX(int x){ //setter设置值
        this.x = x;
    }

    public int getY(){
        return this.y;
    }
    public void setY(int y){
        this.y = y;
    }

}



















