package day01; //声明包day01(楼+单元)
public class HelloWorld { //声明类HelloWorld(房子)
    //主方法，为程序的入口(大门口)，程序的执行从main开始，main结束则程序结束
    public static void main(String[] args) {
        //输出hello world
        //1)严格区分大小写
        //2)所有符号必须是英文模式的
        //3)每句话必须以分号结尾
        System.out.println("hello world"); //双引号中的原样输出
        System.out.println("欢迎大家来到达内");
    }
}


















