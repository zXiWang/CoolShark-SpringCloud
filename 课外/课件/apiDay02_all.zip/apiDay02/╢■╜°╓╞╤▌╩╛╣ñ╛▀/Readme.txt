java -jar BinTools.jar
