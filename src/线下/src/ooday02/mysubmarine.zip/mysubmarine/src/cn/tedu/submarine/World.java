package cn.tedu.submarine;
/** 整个窗口世界 */
public class World {
    public static void main(String[] args) {
        Battleship s = new Battleship();
        ObserveSubmarine os1 = new ObserveSubmarine();
        ObserveSubmarine os2 = new ObserveSubmarine();
        ObserveSubmarine os3 = new ObserveSubmarine();
        ObserveSubmarine os4 = new ObserveSubmarine();
        TorpedoSubmarine ts1 = new TorpedoSubmarine();
        TorpedoSubmarine ts2 = new TorpedoSubmarine();
        MineSubmarine ms1 = new MineSubmarine();
        MineSubmarine ms2 = new MineSubmarine();
        Mine m1 = new Mine(100,200);
        Mine m2 = new Mine(123,435);
        Bomb b1 = new Bomb(200,300);
        Bomb b2 = new Bomb(145,234);

        System.out.println(s.width+","+s.height+","+s.x+","+s.y+","+s.speed+","+s.life);
        System.out.println(os1.width+","+os1.height+","+os1.x+","+os1.y+","+os1.speed);
        System.out.println(os2.width+","+os2.height+","+os2.x+","+os2.y+","+os2.speed);
        System.out.println(os3.width+","+os3.height+","+os3.x+","+os3.y+","+os3.speed);
        System.out.println(os4.width+","+os4.height+","+os4.x+","+os4.y+","+os4.speed);

    }
}


















