package cn.tedu.submarine;

import java.util.Random;

/** 水雷潜艇 */
public class MineSubmarine {
    int width;
    int height;
    int x;
    int y;
    int speed;
    /** 构造方法 */
    MineSubmarine(){
        width = 63;
        height = 19;
        x = -width; //负的潜艇的宽
        Random rand = new Random(); //随机数对象
        y = rand.nextInt(479-height-150+1)+150; //150到(窗口高-潜艇高)之间的随机数
        speed = rand.nextInt(3)+1; //1到3之内的随机数
    }

    void move(){
        System.out.println("水雷潜艇向右移动啦!");
    }
}

















