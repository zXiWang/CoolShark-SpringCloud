package cn.tedu.submarine;
/** 水雷 */
public class Mine {
    int width;
    int height;
    int x;
    int y;
    int speed;
    /** 构造方法 */     //Mine m = new Mine(100,200);
    Mine(int x,int y){ //每个水雷的初始坐标都是不一样的，所以数据不能写死，需传参写活
        width = 11;
        height = 11;
        this.x = x;
        this.y = y;
        speed = 1;
    }

    void move(){
        System.out.println("水雷向上移动啦!");
    }
}


















