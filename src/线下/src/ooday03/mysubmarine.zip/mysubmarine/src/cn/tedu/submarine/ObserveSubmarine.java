package cn.tedu.submarine;

/** 侦察潜艇 */
public class ObserveSubmarine extends SeaObject {
    /** 构造方法 */     //ObserveSubmarine os1 = new ObserveSubmarine();
    ObserveSubmarine(){
        super(63,19);
    }
}



















