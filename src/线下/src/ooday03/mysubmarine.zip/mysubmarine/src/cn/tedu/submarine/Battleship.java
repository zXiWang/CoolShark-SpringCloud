package cn.tedu.submarine;
/** 战舰 */
public class Battleship extends SeaObject {
    int life;   //命数
    /** 构造方法 */
    Battleship(){
        super(66,26,270,124,20);
        life = 5;
    }
}

















