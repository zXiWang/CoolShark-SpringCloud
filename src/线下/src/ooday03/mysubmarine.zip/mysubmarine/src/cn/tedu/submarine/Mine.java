package cn.tedu.submarine;
/** 水雷 */
public class Mine extends SeaObject {
    /** 构造方法 */          //Mine m = new Mine(100,200);
    Mine(int x,int y){
        super(11,11,x,y,1); //传递的是x与y的值
    }
}


















