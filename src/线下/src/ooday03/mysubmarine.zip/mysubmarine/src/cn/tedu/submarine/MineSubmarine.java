package cn.tedu.submarine;
/** 水雷潜艇 */
public class MineSubmarine extends SeaObject {
    /** 构造方法 */
    MineSubmarine(){
        super(63,19);
    }
}

















