package cn.tedu.submarine;
/** 整个窗口世界 */
public class World {
    public static void main(String[] args) {
        ObserveSubmarine[] oses = new ObserveSubmarine[3];
        oses[0] = new ObserveSubmarine();
        oses[1] = new ObserveSubmarine();
        oses[2] = new ObserveSubmarine();
        for(int i=0;i<oses.length;i++){ //遍历所有侦察潜艇
            System.out.println(oses[i].x+","+oses[i].y); //输出每个侦察潜艇的x和y坐标
            oses[i].move(); //每个侦察潜艇移动
        }

        Mine[] ms = new Mine[2];
        ms[0] = new Mine(100,200);
        ms[1] = new Mine(125,345);
        for(int i=0;i< ms.length;i++){ //遍历所有水雷
            System.out.println(ms[i].x+","+ms[i].y+","+ms[i].speed);
            ms[i].move();
        }

        TorpedoSubmarine[] tses = new TorpedoSubmarine[2];
        MineSubmarine[] mses = new MineSubmarine[3];
        Bomb[] bs = new Bomb[4];

    }
}


















