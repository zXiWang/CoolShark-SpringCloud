package cn.tedu.submarine;
import javax.swing.JFrame;
import javax.swing.JPanel; //1.
/** 整个窗口世界 */
public class World extends JPanel { //2.
    public static void main(String[] args) {
        JFrame frame = new JFrame(); //3.
        World world = new World();
        world.setFocusable(true);
        frame.add(world);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(641+16, 479+39);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        /*
        ObserveSubmarine o1 = new ObserveSubmarine();
        System.out.println("侦察艇初始数据:    x:"+o1.x+", y:"+o1.y+", speed:"+o1.speed);
        o1.move();
        System.out.println("侦察艇移动后数据: x:"+o1.x+", y:"+o1.y+", speed:"+o1.speed);

        Mine o2 = new Mine(100,200);
        System.out.println("水雷初始数据:   x:"+o2.x+", y:"+o2.y+", speed:"+o2.speed);
        o2.move();
        System.out.println("水雷移动后数据: x:"+o2.x+", y:"+o2.y+", speed:"+o2.speed);
        */



        /*
        SeaObject[] submarines = new SeaObject[5]; //潜艇数组
        submarines[0] = new ObserveSubmarine(); //向上造型
        submarines[1] = new ObserveSubmarine();
        submarines[2] = new TorpedoSubmarine();
        submarines[3] = new TorpedoSubmarine();
        submarines[4] = new MineSubmarine();
        for(int i=0;i<submarines.length;i++){ //遍历所有潜艇
            SeaObject s = submarines[i]; //获取每个潜艇
            System.out.println(s.x+","+s.y+","+s.speed);
            s.move();
        }

        Mine[] ms = new Mine[2];
        ms[0] = new Mine(100,200);
        ms[1] = new Mine(125,345);
        for(int i=0;i< ms.length;i++){ //遍历所有水雷
            Mine m = ms[i]; //获取每个水雷
            System.out.println(m.x+","+m.y);
            m.move();
        }

        Bomb[] bs = new Bomb[2];
        bs[0] = new Bomb(200,300);
        bs[1] = new Bomb(100,200);
        for(int i=0;i<bs.length;i++){
            Bomb b = bs[i];
            System.out.println(b.x+","+b.y);
            b.move();
        }
         */

    }
}


















