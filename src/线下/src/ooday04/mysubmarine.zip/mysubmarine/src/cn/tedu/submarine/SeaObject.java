package cn.tedu.submarine;

import java.util.Random;

/** 海洋对象 */
public class SeaObject {
    int width;  //宽
    int height; //高
    int x;      //x坐标
    int y;      //y坐标
    int speed;  //移动速度
    /** 专门给侦察潜艇、鱼雷潜艇、水雷潜艇提供的 */
    //因为三种潜艇的width/height的值都是不一样的，所以数据不能写死，需传参写活
    //因为三种潜艇的x/y/speed的值都是一样的，所以数据可以写死，不需要传参
    SeaObject(int width,int height){
        this.width = width;
        this.height = height;
        x = -width; //负的潜艇的宽
        Random rand = new Random(); //随机数对象
        y = rand.nextInt(479-height-150+1)+150; //150到(窗口高-潜艇高)之间的随机数
        speed = rand.nextInt(3)+1; //1到3之内的随机数
    }

    /** 专门给战舰、水雷、炸弹提供的 */
    //因为三种对象的width/height/x/y/speed都是不一样的，所以数据不能写死，需传参写活
    SeaObject(int width,int height,int x,int y,int speed){
        this.width = width;
        this.height = height;
        this.x = x;
        this.y = y;
        this.speed = speed;
    }

    /** 海洋对象移动 */
    void move(){ //------------------------------周五继续处理
        System.out.println("海洋对象移动啦!");
    }
}




















