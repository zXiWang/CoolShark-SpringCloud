package cn.tedu.submarine;
import javax.swing.JFrame;
import javax.swing.JPanel; //1.
import java.awt.*;
import java.util.Arrays;

/** 整个窗口世界 */
public class World extends JPanel { //2.
    public static final int WIDTH = 641;  //窗口的宽
    public static final int HEIGHT = 479; //窗口的高

    //如下这一堆对象就是窗口中你所看到的对象了
    private Battleship ship = new Battleship(); //战舰对象
    private SeaObject[] submarines = {
            new ObserveSubmarine(),
            new TorpedoSubmarine(),
            new MineSubmarine()
    }; //潜艇数组
    private Mine[] mines = {
            new Mine(280,300)
    }; //水雷数组
    private Bomb[] bombs = {
            new Bomb(200,250)
    }; //炸弹数组

    /** 重写paint()画  g:系统自带的画笔 */
    public void paint(Graphics g){
        Images.sea.paintIcon(null,g,0,0); //画海洋图---不要求掌握
        ship.paintImage(g); //画战舰
        for(int i=0;i<submarines.length;i++){ //遍历所有潜艇
            submarines[1].paintImage(g); //画潜艇
        }
        for(int i=0;i<mines.length;i++){ //遍历所有水雷
            mines[i].paintImage(g); //画水雷
        }
        for(int i=0;i<bombs.length;i++){ //遍历所有炸弹
            bombs[i].paintImage(g); //画炸弹
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame(); //3.
        World world = new World(); //会创建窗口中的那一堆对象
        world.setFocusable(true);
        frame.add(world);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(WIDTH+16, HEIGHT+39);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true); //系统自动调用paint()方法
    }
}




















