package cn.tedu.submarine;

import javax.swing.*;

/** 水雷潜艇 */
public class MineSubmarine extends SeaObject {
    /** 构造方法 */
    public MineSubmarine(){
        super(63,19);
    }

    /** 重写move()移动 */
    public void move(){
        x += speed; //x+(向右)
    }

    /** 重写getImage()获取图片 */
    public ImageIcon getImage(){
        return Images.minesubm; //返回水雷潜艇图片
    }
}

















